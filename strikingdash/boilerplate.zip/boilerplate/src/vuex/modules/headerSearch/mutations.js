export default {
  searchHeaderSuccess(state, data) {
    state = data;
  },

  searchHeaderErr(state, err) {
    state = err;
  },
};
