import app from '../../config/configApp';
import VCalendar from 'v-calendar';

app.use(VCalendar, {});
