import app from '../../config/configApp';
import CKEditor from '@ckeditor/ckeditor5-vue';

app.use(CKEditor);
