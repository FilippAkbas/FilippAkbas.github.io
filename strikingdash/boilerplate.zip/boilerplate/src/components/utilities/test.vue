<template>
  <img :src="require('@/static/img/icon/address.svg')" />
</template>

<script>
export default {
  name: 'Test',
};
</script>
