import PageRoutes from './PageRoutes';

const routes = [...PageRoutes];

export default routes;
