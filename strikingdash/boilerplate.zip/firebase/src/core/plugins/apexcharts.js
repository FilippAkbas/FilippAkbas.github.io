import VueApexCharts from 'vue3-apexcharts';
import app from '../../config/configApp';
import VCalendar from 'v-calendar';

app.use(VueApexCharts);
app.use(VCalendar, {});
