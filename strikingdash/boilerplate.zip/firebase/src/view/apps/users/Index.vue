<template>
  <router-view name="child"></router-view>
</template>
<script>
export default {
  name: 'Users',
};
</script>
