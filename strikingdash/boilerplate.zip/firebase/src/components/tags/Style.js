import Styled from 'vue3-styled-components';
import { Tag } from 'ant-design-vue';

const TagStyle = Styled(Tag)`

`;

export { TagStyle };
