import Styled from 'vue3-styled-components';
import { Drawer } from 'ant-design-vue';

const DrawerStyle = Styled(Drawer)`

`;

export { DrawerStyle };
